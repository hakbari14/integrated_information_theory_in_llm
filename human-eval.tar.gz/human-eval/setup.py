from setuptools import setup, find_packages

setup(
    name="human-eval",
    version="1.0",
    packages=find_packages(),
)